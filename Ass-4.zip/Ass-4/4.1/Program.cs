﻿using System;
using properties;
namespace MainProgram
{
    class Program
    {
        public static void Main()
        {
            const string name = "Tenzin Dawa";
            Console.WriteLine($"\nNAME: {name}, TIME: {DateTime.Now.ToString("HH:mm:ss tt")}");
            Console.WriteLine("\nProperties with backing fields...");
            TimePeriod t = new TimePeriod();
            t.Hours = 24;
            Console.WriteLine($"Time in hours: {t.Hours}");
            Console.WriteLine("\nExpression body Definitions...");
            var person = new Person("Tenzin", "Dawa");
            Console.WriteLine($"Name:{person.Name}");
            var item = new SaleItem("Shoes", 19.95m);
            Console.WriteLine($"{item.Name}: sells for {item.Price:C2}");
            Console.WriteLine("\nAuto implemented properties...");
            var autoImplementedItem = new AutoImplementedSaleItem{ Name = "Shirt", Price = 25.50m };
            Console.WriteLine($"{autoImplementedItem.Name}: sells for {autoImplementedItem.Price:C2}");
        }
    }
}