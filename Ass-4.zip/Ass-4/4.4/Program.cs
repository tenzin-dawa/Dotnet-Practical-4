﻿using System;
using Emp;
namespace MainProgram
{
    class Program
    {
        public static void Main(string[] args)
        {
            Permanentemployee e1 = new Permanentemployee("Tenzin","Dawa", "15/12/2014" , "9/2/2022",75000.0,15000,8000,4000);
            Console.WriteLine($"\nInformation of First Employee :\n{e1}");
            e1.giveRaise(10.0);
            Console.WriteLine($"\nInformation of First Employee after 10% raise :\n{e1}");
            Permanentemployee e2 = new
            Permanentemployee("Jaden","Smith", "31/3/2015" , "25/07/2025" ,60000.0,8000,1500,5000);
            Console.WriteLine($"\nInformation of Second Employee :\n{e2}"); 
            e2.giveRaise(10.0);
            Console.WriteLine($"\nInformation of Second Employee after 10% raise :\n{e2}");
        }
    }
}